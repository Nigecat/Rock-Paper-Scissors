Please run any of the top level python scripts to start the program [gui.py, json_data.py, move.py, utils.py] it may take a few seconds to start the first time

When playing, click one of the icons on the top row in the left window, the row underneath it will show the state of the round you last played

The right window will show some interesting information about the game

Some interesting data about the move predictions will be shown in the console window, if you do not want to see this you can minimize it

The game will automatically show a game over window when you reach 20 rounds, this is the round length

Most things with the game can be modified with changing the values in config.json, however, it is recommended to keep them as the default


All the data relating to the game is stored in the data folder
All the images relating to the game are stored in the images folder